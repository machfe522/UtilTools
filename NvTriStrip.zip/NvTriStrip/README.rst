NvTriStrip
==========

`NvTriStrip <http://www.nvidia.com/object/nvtristrip_library.html>`__ library from NVidia, see the
`original readme <NvTriStrip/README.txt>`__ for details.
